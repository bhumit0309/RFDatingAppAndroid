package com.example.macstudent.rfapp;

import java.time.format.DateTimeFormatter;
import java.util.Date;

import io.realm.RealmObject;

/**
 * Created by macstudent on 2018-01-18.
 */

public class AndroidVersion extends RealmObject {
    private String displayName;

//    public AndroidVersion(String displayName, String signature, String city, int gender, int height, double latitude, double longitude, String mainImage) {
//        this.displayName = displayName;
//        this.signature = signature;
//        this.city = city;
//        this.gender = gender;
//        this.height = height;
//        this.latitude = latitude;
//        this.longitude = longitude;
//        this.mainImage = mainImage;
//    }

    public AndroidVersion() {
    }

    public AndroidVersion(String displayName, String signature, String city, int gender, int height, double latitude, double longitude, String mainImage) {
        this.displayName = displayName;
        this.signature = signature;
        this.city = city;
        this.gender = gender;
        this.height = height;
        this.latitude = latitude;
        this.longitude = longitude;
        this.mainImage = mainImage;
    }

    private String signature;
    private String city;
    private int gender;
    private int height;
    private double latitude;
    private double longitude;
    private String mainImage;

    public String getName() {
        return displayName;
    }

    public int getGender()
    {
        return gender;
    }

    public String getSignature() {
        return signature;
    }

    public String getCity() {
        return city;
    }

    public int getHeight() { return height; }

    public double getLatitude() { return latitude; }

    public double getLongitude() { return longitude; }

    public String getMainImage() {
        return mainImage;
    }

}