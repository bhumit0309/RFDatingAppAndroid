package com.example.macstudent.rfapp;

/**
 * Created by macstudent on 2018-01-18.
 */

public class JSONResponse {
    private AndroidVersion[] data;

    public AndroidVersion[] getAndroid() {
        return data;
    }

    public void addToRealm()
    {

    }
}
